<?php

	public function load_assets() {

		if ( is_admin() ) {

			wp_enqueue_script('jquery-ui-sortable');

			wp_enqueue_style( 'handypress-composer', str_replace( WP_CONTENT_DIR, WP_CONTENT_URL,  dirname( __FILE__ ) ) . '/composer.css', false, false, 'screen' );
			wp_enqueue_script('handypress-composer', str_replace( WP_CONTENT_DIR, WP_CONTENT_URL,  dirname( __FILE__ ) ) . '/composer.js', array('jquery'), '1.0', true );

			wp_localize_script( 'handypress-composer', 'handypress_composer_settings', array( 'ajaxurl' => admin_url( 'admin-ajax.php' )));

			wp_enqueue_style( 'bootstrap-4.0.0-grid-composer', str_replace( WP_CONTENT_DIR, WP_CONTENT_URL, dirname( __FILE__ ) ) . '/css/bootstrap-grid-composer.css', false, false, 'screen' );

		}

	}

	public function load( $composer_data ) {

		$this->composer_data = $composer_data;

	}

	// static function get_the_row( $settings, $editor = false ){
	//
	// 	$the_row = array();
	//
	// 	//infos
	// 	$the_row['infos']['title'] = 'row';
	// 	if ( isset( $settings['title'] ) ) $the_row['infos']['title'] = $settings['title'];
	//
	// 	//wrapper
	// 	$the_row['wrapper']['class'] = 'wrapper';
	// 	if ( isset( $settings['wrapper-pos'] ) ) $the_row['wrapper']['class'] .= ' '. $settings['wrapper-pos'];
	//
	// 	$the_row['wrapper']['style'] = '';
	// 	if ( ! $editor && $settings['wrapper-bg-color'] ) $the_row['wrapper']['style'] .= 'background-color:' . $settings['wrapper-bg-color'] . ';';
	//
	// 	//container
	// 	$the_row['container']['class'] = 'container';
	// 	if ( $settings['type'] === 'fluid' ) $the_row['container']['class'] = 'container-fluid';
	// 	if ( $settings['type'] === 'fullwidth' ) $the_row['container']['class'] = 'container-fullwidth';
	// 	if ( isset( $settings['container-pos'] ) ) $the_row['container']['class'] .= ' '. $settings['container-pos'];
	// 	$the_row['container']['style'] = '';
	// 	if ( $settings['max-width'] ) $the_row['container']['style'] .= 'max-width:' . $settings['max-width'] . ';';
	//
	// 	//row
	// 	$the_row['row']['class'] = 'row';
	// 	if ( $settings['gutters'] !== 'true' ) $the_row['row']['class'] .= ' no-gutters';
	// 	if ( $settings['justify'] ) $the_row['row']['class'] .= ' justify-content-' . $settings['justify'];
	// 	if ( $settings['align'] ) $the_row['row']['class'] .= ' align-items-' . $settings['align'];
	// 	if ( $settings['hidden-down'] ) $the_row['row']['class'] .= ' hidden-' . $settings['hidden-down'] . '-down';
	// 	if ( $settings['hidden-up'] ) $the_row['row']['class'] .= ' hidden-' . $settings['hidden-up'] . '-up';
	// 	if ( isset( $settings['row-pos'] ) ) $the_row['row']['class'] .= ' '. $settings['row-pos'];
	// 	$the_row['row']['style'] = '';
	// 	if ( $settings['max-width'] ) $the_row['row']['style'] .= 'max-width:' . $settings['max-width'] . ';';
	// 	if ( ! $editor && $settings['padding'] ) $the_row['row']['style'] .= 'padding:' . $settings['padding'] . ';';
	//
	// 	return $the_row;
	//
	// }
	//
	// static function get_the_column( $settings, $editor = false ){
	//
	// 	$the_column = array();
	//
	// 	//infos
	// 	$the_column['infos']['title'] = 'column';
	// 	if ( $settings['title'] ) $the_column['infos']['title'] = $settings['title'];
	//
	// 	//column
	// 	$the_column['column']['class'] = '';
	// 	if ( $settings['col'] )    $the_column['column']['class'] .= ' col-' . $settings['col'];
	// 	if ( $settings['col-sm'] ) $the_column['column']['class'] .= ' col-sm-' . $settings['col-sm'];
	// 	if ( $settings['col-md'] ) $the_column['column']['class'] .= ' col-md-' . $settings['col-md'];
	// 	if ( $settings['col-lg'] ) $the_column['column']['class'] .= ' col-lg-' . $settings['col-lg'];
	// 	if ( $settings['col-xl'] ) $the_column['column']['class'] .= ' col-xl-' . $settings['col-xl'];
	// 	if ( $the_column['column']['class'] == '' ) $the_column['column']['class'] = 'col ' . $the_column['column']['class'];
	// 	if ( $settings['offset'] ) $the_column['column']['class'] .= ' offset-' . $settings['offset'];
	// 	if ( $settings['hidden-down'] ) $the_column['column']['class'] .= ' hidden-' . $settings['hidden-down'] . '-down';
	// 	if ( $settings['hidden-up'] ) $the_column['column']['class'] .= ' hidden-' . $settings['hidden-up'] . '-up';
	// 	if ( $settings['align'] ) $the_column['column']['class'] .= ' align-self-' . $settings['align'];
	//
	// 	//style
	// 	$the_column['column']['style'] = '';
	// 	if ( ! $editor && $settings['background-color'] ) $the_column['column']['style'] .= 'background-color:' . $settings['background-color'] . ';';
	// 	if ( $settings['max-width'] ) $the_column['column']['style'] .= 'max-width:' . $settings['max-width'] . ';';
	// 	if ( $settings['padding'] ) $the_column['column']['style'] .= 'padding:' . $settings['padding'] . ';';
	//
	// 	//clearfix
	// 	$the_column['column']['clearfix'] = '';
	// 	if ( $settings['clearfix'] ) $the_column['column']['clearfix'] .= '<div class="clearfix ' . $settings['clearfix'] . '"></div>';
	//
	// 	return $the_column;
	//
	// }

	static function get_the_item( $item ) {

		$the_item = $item;

 		$the_item['title'] = '';
		if ( isset( $item['title'] ) ) {
			$the_item['title'] = strip_tags( $item['title'] );
		} else if ( isset( $item['type'] ) ) {
			$the_item['title'] = strip_tags( $item['type'] );
		}

		if ( isset( $item['icon'] ) && $item['icon'] ) {
			$the_item['icon'] = $item['icon'];
		} else {
			$the_item['icon'] = 'no-icon';
		}

		return $the_item;

	}

	public function editor() {

		?>

			<div class="composer-editor" composer-id="<?php echo $this->composer_id; ?>" style="<?php if ( $this->composer_settings['border'] == true ) echo 'border: 1px solid #ddd;'; ?>">

				<div class="composer-editor-scroll">

				<?php if ( $this->composer_settings['toolbar'] ) { ?>

					<div class="composer-toolbar-top">

					  <div class="composer-toolbar-left">
							<span class="composer-actions composer-bt dashicons dashicons-editor-table"></span>
					  	<span class="composer-action-undo composer-bt fa fa-undo"></span>
					  	<span class="composer-action-repeat composer-bt fa fa-repeat"></span>
					  	<!-- <span class="composer-action-add composer-bt fa fa-plus"></span> -->
					  </div>

					  <div class="composer-toolbar-right">
					  	<span class="composer-action-preview composer-bt fa fa-eye"></span>
					  	<span class="composer-action-xray composer-bt fa fa-low-vision"></span>
					  	<span class="composer-action-source composer-bt fa fa-code"></span>
					  	<span class="composer-action-debug composer-bt fa fa-bug"></span>
					  	<span class="composer-action-fullscreen composer-bt fa fa-arrows-alt"></span>
					  </div>

					</div>

				<?php } ?>

				<div class="composer-layout">

					<div class="composer-rows">

						<?php if ( $this->composer_data ) { foreach ( $this->composer_data as $row_key => $row ) { ?>

							<?php if( isset( $row['_type'] ) && $row['_type'] == 'block' ) { ?>

								<div class="composer-row composer-block" composer-row-type="<?php echo $row['settings']['_type']; ?>">

									<div class="composer-block-over"></div>

									<div class="composer-block-tools">

										<div class="composer-block-toolbar">

											<div class="composer-block-move composer-block-handlebar"></div>

											<div class="composer-block-toolbar-left">

												<div class="composer-info composer-block-type">Block</div><div class="composer-info composer-block-title"><?php echo $row['settings']['title']; ?></div>

												<div class="composer-info">
													<span class="composer-block-bg-color" style="background-color:"></span>
												</div>

											</div>

											<div class="composer-block-toolbar-right">

												<div class="composer-block-toolbar-actions">

													<div class="composer-row-move composer-bt fa fa-arrows-v ui-sortable-handle"></div>

													<div class="composer-row-clone composer-bt fa fa-clone"></div>

													<div class="composer-row-delete composer-bt fa fa-trash-o"></div>

													<div class="composer-block-edit composer-bt fa fa-pencil"></div>

												</div>

												<div class="composer-block-tools-button composer-bt composer-bt-light fa fa-ellipsis-h"></div>

											</div>

										</div>

									</div>

									<textarea style="display:none;width:100%;" class="composer-block-value" type="textarea" autocorrect="off" autocomplete="off" spellcheck="false" placeholder=""><?php echo json_encode( $row['settings'] ); ?></textarea>

									<div class="composer-block-preview"></div>

								</div>

							<?php } else { ?>

								<?php  $the_row = self::get_the_row( $row['settings'], true ); ?>

								<div class="composer-row" composer-row-type="<?php echo $row['settings']['_type']; ?>">

									<div class="composer-row-tools">

										<div class="composer-row-toolbar">

											<div class="composer-row-move composer-row-handlebar"></div>

											<div class="composer-row-toolbar-left">

												<div class="composer-info composer-row-title"><?php echo $the_row['infos']['title']; ?></div>

												<div class="composer-info">
													<span class="composer-row-bg-color" style="background-color:<?php //echo $the_row['wrapper']['css']['background-color']; ?>"></span>
												</div>

											</div>

											<div class="composer-row-toolbar-right">

												<div class="composer-row-toolbar-actions">

													<div class="composer-row-move composer-bt fa fa-arrows-v"></div>

													<div class="composer-row-clone composer-bt fa fa-clone"></div>

													<div class="composer-row-delete composer-bt fa fa-trash-o"></div>

													<div class="composer-row-edit composer-bt fa fa-pencil"></div>

												</div>

												<div class="composer-row-tools-button composer-bt composer-bt-light fa fa-ellipsis-h"></div>

											</div>

										</div>

									</div>

									<textarea style="display:none;width:100%;" class="composer-row-value" type="textarea" autocorrect="off" autocomplete="off" spellcheck="false" placeholder=""><?php echo json_encode( $row['settings'] ); ?></textarea>

									<?php
									/*
									*
									* CONTAINER
									*
									*/
									?>

									<div class="<?php echo $the_row['wrapper']['class']; ?>" style="<?php echo $the_row['wrapper']['style']; ?>">

										<div class="composer-wrapper-margin"><div class="composer-wrapper-padding">

											<div class="<?php echo $the_row['container']['class']; ?>" style="<?php echo $the_row['container']['style']; ?>">

												<div class="<?php echo $the_row['row']['class']; ?> composer-row-content" style="<?php echo $the_row['row']['style']; ?>">

													<?php foreach ( $row['content'] as $col_key => $col ) { ?>

														<?php  $the_column = self::get_the_column( $col['settings'], true ); ?>

														<div class="composer-column <?php echo $the_column['column']['class']; ?>" style="<?php echo $the_column['column']['style']; ?>" composer-column-type="<?php echo $col['settings']['_type']; ?>">

															<div class="composer-column-padding-top"></div>
															<div class="composer-column-padding-left"></div>
															<div class="composer-column-padding-right"></div>
															<div class="composer-column-padding-bottom"></div>

															<div class="composer-column-inner">

																<div class="composer-column-tools">

																	<div class="composer-column-toolbar">

																		<div class="composer-column-move composer-column-handlebar"></div>

																		<div class="composer-column-toolbar-left">

																			<div class="composer-info composer-column-title"><?php echo $the_column['infos']['title']; ?></div>

																		</div>

																		<div class="composer-column-toolbar-right">

																			<div class="composer-column-toolbar-actions">

																				<div class="composer-column-move composer-bt fa fa-arrows-h"></div>

																				<div class="composer-column-clone composer-bt fa fa-clone"></div>

																				<div class="composer-column-delete composer-bt fa fa-trash-o"></div>

																				<div class="composer-column-edit composer-bt fa fa-pencil"></div>

																			</div>

																			<div class="composer-column-tools-button composer-bt composer-bt-light fa fa-ellipsis-h"></div>

																		</div>

																	</div>



																</div>

																<textarea style="display:none;width:100%;" class="composer-column-value" type="textarea" autocorrect="off" autocomplete="off" spellcheck="false" placeholder=""><?php echo json_encode( $col['settings'] ); ?></textarea>

																<?php
																/*
																*
																* ITEMS
																*
																*/
																?>

																<div id="composer-<?php echo $row_key; ?>-<?php echo $col_key; ?>" class="composer-items" style="<?php //echo $the_column['inner']['style']; ?>">

																	<div class="composer-item-empty"></div>

																	<?php if ( isset( $this->composer_data[ $row_key ]['content'][ $col_key ]['content'] ) && $this->composer_data[ $row_key ]['content'][ $col_key ]['content'] ) { ?>

																		<?php foreach ( $this->composer_data[ $row_key ]['content'][ $col_key ]['content'] as $item_key => $item ) { ?>

																			<?php $the_item = self::get_the_item( $item ); ?>

																			<div class="composer-item" composer-item-type="<?php echo $the_item['_type']; ?>">

																				<div class="composer-item-toolbar">

																					<div class="composer-item-move composer-item-handlebar"></div>

																		 			<div class="composer-item-toolbar-left">
																							<span class="composer-item-icon composer-bt <?php echo $the_item['icon']; ?>"></span>
																							<span class="composer-item-title"><?php echo $the_item['title']; ?></span>
																							<span class="composer-item-infos"></span>
																		 			</div>

																					<div class="composer-item-toolbar-right">

																						<div class="composer-item-toolbar-actions">

																							<!-- <span class="composer-item-title"><?php echo $the_item['title']; ?></span> -->

																							<?php if( in_array( 'sort', $editor['options']['actions'] ) ) echo '<div class="composer-item-move composer-bt fa fa-arrows ui-sortable-handle"></div>'; ?>
																							<?php if( in_array( 'clone', $editor['options']['actions'] ) ) echo '<div class="composer-item-clone composer-bt fa fa-clone"></div>'; ?>
																							<?php if( in_array( 'delete', $editor['options']['actions'] ) ) echo '<div class="composer-item-delete composer-bt fa fa-trash-o"></div>'; ?>
																							<?php if( in_array( 'edit', $editor['options']['actions'] ) ) echo '<div class="composer-item-edit composer-bt fa fa-pencil"></div>'; ?>


																						</div>

																						<div class="composer-item-tools-button composer-bt composer-bt-light fa fa-ellipsis-h"></div>

																					</div>

																				</div>

																	 			<textarea style="display:none" class="composer-item-value" type="textarea" autocorrect="off" autocomplete="off" spellcheck="false" placeholder=""><?php echo  json_encode( $the_item, JSON_UNESCAPED_UNICODE ); ?></textarea>

																	 		</div>

																		<?php } ?>

																	<?php } ?>

																</div>

																<div class="composer-column-tools-bottom">

																	<span class="composer-modal-add-bt composer-bt fa fa-plus" composer-target="element"></span>

																</div>

															</div>

														</div>

														<?php //echo $clearfix; ?>

													<?php } ?>

												</div>

											</div>

										</div></div>

									</div>

								</div>

							<?php } ?>

						<?php } } ?>

					</div>

					<?php include dirname( __FILE__ ) . '/composer-template-empty.php'; ?>

				</div>

				<div class="composer-toolbar-bottom">

				  <div class="composer-add-items-quick">

				    <ul>

				       <li class="composer-add-item-quick">

				        <!-- <div class="composer-row-add button-secondary" >ADD ROW</div> <div class="composer-preset-add button-secondary" >ADD PRESET</div> -->

								<span class="composer-modal-add-bt composer-bt fa fa-plus" composer-target="element"></span>

								<span class="composer-row-add composer-bt fa fa-plus"></span>

				      </li>

				    </ul>

				  </div>

				</div>



</div><!-- ???? -->


				<?php $this->preview(); ?>

				<?php $this->modal(); ?>

				<?php //$this->blocks(); ?>

				<?php $this->items(); ?>

				<div class="composer-source" style="">
					<textarea name="<?php echo $this->composer_id; ?>" id="<?php echo $this->composer_id; ?>" class="wp-field-value meta-field" type="textarea" autocorrect="off" autocomplete="off" spellcheck="false" placeholder="" /><?php echo json_encode( $this->composer_data, JSON_UNESCAPED_UNICODE ); ?></textarea>
				</div>

				<textarea style="display: block;" class="wp-field-options" type="textarea" autocorrect="off" autocomplete="off" spellcheck="false" placeholder="" /><?php echo json_encode( $this->composer_settings, JSON_UNESCAPED_UNICODE ); ?></textarea>

				<script class="composer-template-item" type="text/template"><?php include dirname( __FILE__ ) . '/composer-template-item.php'; ?></script>

			</div>

		<?php

	}

	public function modal() {

		echo '<div class="composer-modal-edit composer-modal">';

			echo '<div class="composer-modal-bg composer-modal-close"></div>';

		 	echo '<div class="composer-modal-container">';

		    	echo '<div class="composer-modal-toolbar-top">';

		      		echo '<div class="composer-modal-toolbar-left">';

		      			echo '<span class="composer-modal-toolbar-title">Title</span>';

		      		echo '</div>';

		      		echo '<div class="composer-modal-toolbar-right">';

		      			echo '<span class="composer-modal-close composer-bt dashicons dashicons-no"></span>';

		      		echo '</div>';

		    	echo '</div>';

		    	echo '<div class="composer-modal-content">';

					echo '<iframe width="100%" src=""></iframe>';

					echo '<span class="spinner spinner-center"></span>';

				echo '</div>';

					// echo '<div class="composer-modal-toolbar-bottom">';
					//
		      // 		echo '<div class="composer-modal-toolbar-left">';
					//
		      // 		echo '</div>';
					//
		      // 		echo '<div class="composer-modal-toolbar-right">';
					//
		      // 			echo '<div class="composer-modal-close button button-large button-error">Cancel</div> <div class="composer-item-save button button-large button-success">Validate</div>';
					//
		      // 		echo '</div>';
					//
		    	// echo '</div>';

			echo '</div>';

		echo '</div>';

	}

	public function blocks() {

		echo '<div class="composer-modal-add composer-modal">';

			echo '<div class="composer-modal-bg composer-modal-close"></div>';

		 	echo '<div class="composer-modal-container">';

		    	echo '<div class="composer-modal-toolbar-top">';

		      		echo '<div class="composer-modal-toolbar-left">';

		      			echo '<span class="composer-modal-toolbar-title">Add Blocks</span>';

		      		echo '</div>';

		      		echo '<div class="composer-modal-toolbar-right">';

		      			echo '<span class="composer-modal-close composer-bt dashicons dashicons-no"></span>';

		      		echo '</div>';

		    	echo '</div>';

		    	echo '<div class="composer-modal-content">';

					if ( $this->composer_blocks ){

						echo '<div class="composer-add-items row no-gutters">';

						foreach ( $this->composer_blocks as $block_type => $block ) {

							echo '<div class="composer-add-item col-md-3 col-lg-2 composer-item-add">';

								echo '<div class="composer-add-item-content">';


									echo '<div class="composer-add-item-bottom-left">';

										if( ! $block['icon'] ) $block['icon'] = 'fa fa-cube';
										echo '<div class="composer-item-title"><span class="' . $block['icon'] . '"></span> ' . $block['title'] . '</div>';
										echo '<div class="composer-item-desc">' . $block['desc'] . '</div>';

									echo '</div>';

									echo '<div class="composer-add-item-bottom-right">';

										//echo '<span class="composer-item-add composer-bt fa fa-plus"></span>';
										//echo '<div class="composer-item-add button">ADD</div>';

									echo '</div>';

								echo '</div>';

								$block_default = array( '_type' => $block_type );

								if ( $block['settings'] ){
									foreach ( $block['settings'] as $settings_id => $settings ) {

										$block_default[$settings_id] = $settings['default'];

									}
								}

								echo '<textarea class="composer-item-value" style="display:none" type="textarea" autocorrect="off" autocomplete="off" spellcheck="false" placeholder="">' . json_encode( $block_default, JSON_UNESCAPED_UNICODE ) . '</textarea>';

							echo '</div>';

						}

						echo '</div>';

					}

				echo '</div>';

			echo '</div>';

		echo '</div>';

	}

	public function items() {

		echo '<div class="composer-modal-add composer-modal">';

			echo '<div class="composer-modal-bg composer-modal-close"></div>';

		 	echo '<div class="composer-modal-container">';

		    	echo '<div class="composer-modal-toolbar-top">';

		      		echo '<div class="composer-modal-toolbar-left">';

		      			echo '<span class="composer-modal-toolbar-title">Add Elements</span>';

		      		echo '</div>';

		      		echo '<div class="composer-modal-toolbar-right">';

		      			echo '<span class="composer-modal-close composer-bt dashicons dashicons-no"></span>';

		      		echo '</div>';

		    	echo '</div>';

		    	echo '<div class="composer-modal-content">';

					if ( $this->composer_elements ){

						echo '<div class="composer-add-items row no-gutters">';

						foreach ( $this->composer_elements as $item_type => $item ) {

							echo '<div class="composer-add-item col-6 composer-item-add">';

								echo '<div class="composer-add-item-content">';


									echo '<div class="composer-add-item-bottom-left">';

										if( ! $item['icon'] ) $item['icon'] = 'fa fa-cube';
										echo '<div class="composer-item-title"><span class="' . $item['icon'] . '"></span> ' . $item['title'] . '</div>';
										echo '<div class="composer-item-desc">' . $item['desc'] . '</div>';

									echo '</div>';

									echo '<div class="composer-add-item-bottom-right">';

										//echo '<span class="composer-item-add composer-bt fa fa-plus"></span>';
										//echo '<div class="composer-item-add button">ADD</div>';

									echo '</div>';

								echo '</div>';

								$item_default = array( '_type' => $item_type );

								if ( $item['settings'] ){
									foreach ( $item['settings'] as $settings_id => $settings ) {

										$item_default[$settings_id] = $settings['default'];

									}
								}

								echo '<textarea class="composer-item-value" style="display:none" type="textarea" autocorrect="off" autocomplete="off" spellcheck="false" placeholder="">' . json_encode( $item_default, JSON_UNESCAPED_UNICODE ) . '</textarea>';

							echo '</div>';

						}

						echo '</div>';

					}

				echo '</div>';

			echo '</div>';

		echo '</div>';

	}

	public function preview() {

		echo '<div class="composer-preview"><iframe width="100%" src="' . admin_url( 'admin-ajax.php' ) . '?action=handypress_composer_preview&composer_id=' . $this->composer_id . '"></iframe></div>';

	}


	public function layout( $composer_data ) {

		if ( $composer_data ) {
			foreach ( $composer_data as $row_key => $row ) {

				if( is_callable( $this->composer_rows[ $row['settings']['_type'] ]['render'] ) ) {

					$defaults = array();
					if ( $this->composer_rows[ $row['settings']['_type'] ]['settings'] ) {
						foreach ( $this->composer_rows[ $row['settings']['_type'] ]['settings'] as $key => $value) {

							$defaults[$key] = "";

						}
					}
					$row['settings'] = array_merge( $defaults, $row['settings'] );

					call_user_func( $this->composer_rows[ $row['settings']['_type'] ]['render'], $row, $row['content'], array( "rows" => $this->composer_rows, "columns" => $this->composer_columns, "elements" => $this->composer_elements ) );

				}

			}

		}

	}

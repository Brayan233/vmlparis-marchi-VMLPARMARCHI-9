<?php

/* save temp settings */
function ajax_handypress_composer_temp_settings() {

  update_option( 'handypress_composer_temp_settings', $_REQUEST["settings"] );

  die( json_encode( array( 'type' => 'success', 'block_id' => $_REQUEST["block_id"]) ) );

}

add_action( 'wp_ajax_handypress_composer_temp_settings', 'ajax_handypress_composer_temp_settings' );


/* edit */
function ajax_handypress_composer_edit() {


  remove_action( 'wp_head', 'print_emoji_detection_script' );
  remove_action( 'wp_print_styles', 'print_emoji_styles' );
  remove_action( 'admin_print_scripts', 'print_emoji_detection_script' );
  remove_action( 'admin_print_styles', 'print_emoji_styles' );
  remove_action( 'embed_head', 'print_emoji_detection_script' );

  wp_enqueue_script( 'jquery');
  wp_enqueue_script( 'jquery-ui-core');
  wp_enqueue_script( 'jquery-ui-sortable');

  include dirname( __FILE__ ) . '/composer-header.php';

  global $ADMINBLOCKS;
  global $WPBLOCKS;
  
  //_HANDYLOG( $WPBLOCKS::$FIELDS );
  
  $items = array();

  if ( isset( $ADMINBLOCKS[ $_REQUEST['composer_id'] ] ) ) {

    $FIELD = $ADMINBLOCKS[ $_REQUEST['composer_id'] ];

    $data = json_decode( stripslashes( get_option( 'handypress_composer_temp_settings' ) ), true );

    if ( is_callable( $FIELD['options']['items'] ) ) {

      $items = call_user_func( $FIELD['options']['items'] );

    } else {

      $items = $FIELD['options']['items'];

    }

  }

  $tabs = array();

  // _HANDYLOG('items',$items);

  //order by tab
  if( isset( $items[ $data['type'] ]['options'] ) ){
    foreach ( $items[ $data['type'] ]['options'] as $field_id => $field ) {

      if ( ! isset( $field['tab'] ) ){
        $tabs[ 'General' ][ $field_id ] = $field;
      } else {
        $tabs[ $field['tab'] ][ $field_id ] = $field;
      }

    }
  }

  //print
  echo '<div class="ADMINBLOCKS-tab" data-tab-style="nav">';

    $tab_id = 0;

    if( isset( $tabs ) && count( $tabs ) > 1 ){

      echo '<div class="wp-filter"><ul class="ADMINBLOCKS-tab-nav filter-links">';

      foreach ( $tabs as $tab_title => $tab ) {

          if ( $tab_id == 0 ){
            $state = ' current';
          } else{
            $state = '';
          };

          echo '<li id="tab-' . $tab_title . '"><a id="tab_' . $tab_id . '-ADMINBLOCKS-tab-nav-id" class="ADMINBLOCKS-tab-nav-item' . $state . '" href="#content_' . $tab_id . '" >' . $tab_title . '</a></li>';

          $tab_id++;

      }

      echo '</ul></div>';

    }

    $content_id = 0;

    if( isset( $tabs ) ){

      echo '<div class="ADMINBLOCKS-tab-content">';

        foreach ( $tabs as $tab_title => $tab ) {

          $state = '';
          if ( $content_id == 0 ) $state .= ' content-tab-active';

          echo '<div id="content_' . $content_id . '-ADMINBLOCKS-tab-content-id" class="ADMINBLOCKS-tab-content-item' . $state . '">';

            echo '<div class="container-fullwidth">';
            echo '<div class="row no-gutters">';

              if( isset( $tab ) ){
                foreach ( $tab as $field_id => $field ) {

                  $field['id'] = $field_id;

                  if ( isset( $data['options'][ $field['id'] ] ) ) {

                    $field['value'] = $data['options'][ $field['id'] ];

                  } else {

                    $field['value'] = "";

                  }

                  if ( isset( $field['options']['placeholder'] ) && $field['default'] != "" ) {

                    $field['options']['placeholder'] = $field['default'];

                    if ( isset( $field['options']['data'] ) && $field['options']['data'] ) {
                      foreach ( $field['options']['data'] as $options_data_key => $options_data ) {

                        if ( $options_data['value'] == $field['default'] ) $field['options']['placeholder'] =  $options_data['title'];

                      }

                    }

                  }

                  //if ( $field['type'] == 'json' ) _HANDYLOG($field['options']['data']);

                  if ( is_dir( $field['type'] ) ) {

                    $field_type = explode('/', $field['type'] );
                    $field_type = end( $field_type );

                    if ( file_exists( $field['type'] . '/' . $field_type . '.php' ) ) {

                      if ( ! $field['col'] ) $field['col'] = "col-12";

                      echo '<div class="'. $field['col'] .'">';

                        include $field['type'] . '/' . $field_type . '.php';

                      echo '</div>';

                    }

                  } else if ( file_exists( WP_CONTENT_DIR . '/plugins/blocks/admin/fields/' . $field['type'] . '/' . $field['type'] . '.php' ) ) {

                      if ( ! $field['col'] ) $field['col'] = "col-12";
                      if ( ! $field['options'] ) $field['options'] = array();

                      echo '<div class="'. $field['col'] .'">';

                          include WP_CONTENT_DIR . '/plugins/blocks/admin/fields/' . $field['type'] . '/' . $field['type'] . '.php';

                      echo '</div>';

                  } else {

                    echo $field['type'];
                    
                  }

                  if ( isset( $field['help'] ) && $field['help'] === true ) { echo '<pre>'; var_dump($field); echo '</pre>'; }

                }
              }

              echo '</div>';
              echo '</div>';

            $content_id++;

          echo '</div>';

        }

      echo '</div>';

    }

  echo '</div>';

  echo '<div class="composer-modal-toolbar-inner">';

    echo '<div class="composer-modal-toolbar-inner-left"><textarea style="display:none" class="composer-modal-item-infos" type="textarea" autocorrect="off" autocomplete="off" spellcheck="false" placeholder="">' . $items[ $data['type'] ]['infos'] . '</textarea></div>';
    echo '<div class="composer-modal-toolbar-inner-right"><div class="composer-modal-close button button-large button-error">Cancel</div> <div class="composer-item-save button button-large button-success">OK</div></div>';

  echo '</div>';

  include dirname( __FILE__ ) . '/composer-footer.php';

  die();

}

add_action( 'wp_ajax_handypress_composer_edit', 'ajax_handypress_composer_edit' );

?>

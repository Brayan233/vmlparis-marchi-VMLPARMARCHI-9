<div class="composer-empty" style="display:none;">
	<span class="dashicons dashicons-editor-table" style="padding-top: 2px; padding-right: 4px;"></span>
	<h1>Composer</h1>
	<p>Add row, blocks or element...</p>
</div>

<?php

$default_options = array(
	'data' => array(),
	'name' => 'Edit',
	'title' => '',
	'desc' => '',
	'collapsed' => true,
	'default_source' => false,
	'border' => true,
	'toolbar' => true,
	'maxDepth' => 5,
	'group' => 1,
	//'row' => 1,
	//'column' => 1,
	'type' => 'block',
	'items' => array(),
	'actions' => array( 'edit' ,'sort' ,'delete' ,'add' ,'clone' ),
	'empty' => true,
	'empty_message' => '',
);

$field['options'] = wp_parse_args( $field['options'], $default_options );

?>

<div class="wp-field wp-field-composer <?php if( $field['fullwidth'] ) { echo 'fullwidth'; } ?>" style="display: block;padding:<?php echo $field['padding']; ?>">

	<?php if( $field['title'] ) { ?>
		<div class="field-title" ><?php echo $field['title']; ?></div>
	<?php } ?>

	<div class="field-content">

		<?php if( $field['info'] ) { ?>
			<div class="field-info" ><?php echo $field['info']; ?></div>
		<?php } ?>

			<?php

			include dirname( __FILE__ ) . '/composer.class.php';

			//if ( is_callable( $field['options']['rows'] ) ) $field['options']['rows'] = call_user_func( $field['options']['rows'] );
			//if ( is_callable( $field['options']['columns'] ) ) $field['options']['columns'] = call_user_func( $field['options']['columns'] );
			if ( is_callable( $field['options']['items'] ) ) $field['options']['items'] = call_user_func( $field['options']['items'] );

			if ( ! is_array( $field['value'] ) ) {
				
				//$field['value'] = stripslashes( $field['value'] );
				$field['value'] = json_decode( $field['value'], true );

				$json_error = "";

				switch (json_last_error()) {
					case JSON_ERROR_NONE:
						//echo 'Aucune erreur';
					break;
					case JSON_ERROR_DEPTH:
						$json_error = 'Profondeur maximale atteinte';
					break;
					case JSON_ERROR_STATE_MISMATCH:
						$json_error = 'Inadéquation des modes ou underflow';
					break;
					case JSON_ERROR_CTRL_CHAR:
						$json_error = 'Erreur lors du contrôle des caractères';
					break;
					case JSON_ERROR_SYNTAX:
						$json_error = 'Erreur de syntaxe ; JSON malformé';
					break;
					case JSON_ERROR_UTF8:
						$json_error = 'Caractères UTF-8 malformés, probablement une erreur d\'encodage';
					break;
					default:
						$json_error = 'Erreur inconnue';
					break;
				}
				
			}
			
			//if ( ! $field['value'] ) $field['value'] = false;

			handypress_composer::render( $field['value'], $field['options']['items'], $field );

			?>

		<?php if( $field['desc'] ) { ?>
			<div class="field-description" ><?php echo $field['desc']; ?></div>
		<?php } ?>

	</div>

</div>

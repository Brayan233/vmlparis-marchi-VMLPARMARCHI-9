<?php

if ( ! class_exists('handypress_composer') ) {

class handypress_composer {

	static $ITEM_COUNT = 0;

	static $EDITOR_STYLE;

	static function render( $items, $elements, $editor = false, $preview = false ) {

		if ( $editor ) self::render_editor_header( $items, $elements, $editor, $preview );

			self::render_elements( $items, $elements, $editor, $preview );

		if ( $editor ) self::render_editor_footer( $items, $elements, $editor, $preview );

	}

	static function render_elements( $items = array(), $elements = array(), $editor = false, $preview = false ) {

		if ( $items ) {

			foreach ( $items as $element_key => $item ) {

				if ( isset( $item['type'] ) && isset( $elements[ $item['type'] ] ) ) {

					if ( ! isset( $item['contents'] ) ) $item['contents'] = array();

					//set default options
					$options = array();

					//set default options
					if( $elements[ $item['type'] ]['options'] ){
						foreach ( $elements[ $item['type'] ]['options'] as $option_key => $option ) {

							if ( $preview && isset( $option['dummy'] ) ) {
								$options[$option_key] = $option['dummy'];
							} else if ( isset( $item['options'][$option_key] ) && $item['options'][$option_key] ) {
								$options[$option_key] = $item['options'][$option_key];
							} else if ( isset( $option['default'] ) && $option['default'] && $option['type'] !== 'checkbox' ) {
								$options[$option_key] = $option['default'];
							} else {
								$options[$option_key] = "";
							}

						}
					}

					//add custom options if exist
					if ( isset( $item['options'] ) && $item['options'] ) $options = array_merge( $options, $item['options'] );

					//set default content
					$contents = array();
					if ( isset( $item['contents'] ) ) $contents = $item['contents'];

					$type = $item['type'];
					$title = $elements[ $item['type'] ]['title'];
					if ( $elements[ $item['type'] ]['icon'] ) { $icon = $elements[ $item['type'] ]['icon']; } else { $icon = 'no-icon'; }

					$item['id'] = 'block_' . handypress_composer::$ITEM_COUNT;
					handypress_composer::$ITEM_COUNT++;
					
					//create element
					if ( $editor ) {

						if ( isset( $elements[ $item['type'] ]['editor'] ) && is_callable( $elements[ $item['type'] ]['editor'] ) ) {

							call_user_func( $elements[ $item['type'] ]['editor'], $item, $type, $title, $icon, $options, $contents, $elements, $editor, $preview );

						} else {

							handypress_composer::render_editor_element( $item, $type, $title, $icon, $options, $contents, $elements, $editor, $preview );

						}

					} else {

						if ( isset( $elements[ $item['type'] ]['render'] ) && is_callable( $elements[ $item['type'] ]['render'] ) ) {
							
							//self::render_element_header( $item, $type, $title, $icon, $options, $contents, $elements, $editor );
							
							call_user_func( $elements[ $item['type'] ]['render'], $item, $type, $title, $icon, $options, $contents, $elements, $editor, $preview );
							//call_user_func( $elements[ $item['type'] ]['render'], $item, $options, $contents, $elements, $editor );

							//self::render_element_footer( $item, $type, $title, $icon, $options, $contents, $elements, $editor );

						}

					}

				}

			}

		}

	}

	static function render_editor_element( $item, $type, $title, $icon, $options, $contents, $elements, $editor ) {

		self::render_editor_element_header( $item, $type, $title, $icon, $options, $contents, $elements, $editor );

		self::render_editor_element_footer( $item, $type, $title, $icon, $options, $contents, $elements, $editor );

	}

	static function render_element_header( $item, $type, $title, $icon, $options, $contents, $elements, $editor ) {
		
		$params_defaults = array(
			'class' => '',
		);

		$params = array_merge( $params_defaults, $item['params'] );
		
		$class = $type;
		if ( $params['class'] && is_array( $params['class'] ) ) $params['class'] = implode(' ', array_filter( $params['class'] ) );
		if ( $params['class'] ) $class .= ' ' . $params['class'];
		if ( $options['_block_default_display'] ) $class .= ' ' . str_replace(',', ' ', $options['_block_default_display'] );

		$style = ''; 
		$style .= '#' . $item['id'] . ' {';
			if ( $options['_block_default_margin'] ) $style .= 'margin:' . $options['_block_default_margin'] . ';';
			if ( $options['_block_default_padding'] ) $style .= 'padding:' . $options['_block_default_padding'] . ';';
			if ( $options['_block_default_bg_color'] ) $style .= 'background-color:' . $options['_block_default_bg_color'] . ';';
		$style .= '}';
		   
		block( 'add_style', $style );

		?>
		
		<div id="<?php echo $item['id']; ?>" class="<?php echo $class; ?>" >
		
		<?php

	}

	static function render_element_footer( $item, $type, $title, $icon, $options, $contents, $elements, $editor ) {

		?>

		</div>

		<?php

	}
	
	static function render_editor_element_header( $item, $type, $title, $icon, $options, $contents, $elements, $editor ) {

		$element_class = '.composer-item.' . $type;

		$style_background = $elements[ $item['type'] ]['background'];
		$style_color = $elements[ $item['type'] ]['color'];
		//if( $elements[ $item['type'] ]['background'] ) $style_background = handypress_helper::hex2rgb( $elements[ $item['type'] ]['background'], true, false );
		//if( $elements[ $item['type'] ]['color'] ) $style_color = handypress_helper::hex2rgb( $elements[ $item['type'] ]['color'], true, false );

		$element_style = '';

		$element_style .= $element_class . ' > .composer-item-bg {';
			$element_style .= 'background-color:' . $style_background . ';';
		$element_style .= '}';
		$element_style .= $element_class . ' > .composer-item-toolbar *,';
		$element_style .= $element_class . '.hover > .composer-item-toolbar * {';
			$element_style .= 'color:' . $style_color . '!important;';
		$element_style .= '}';
		$element_style .= $element_class . ' ' . $element_class . '-contents > .composer-item-toolbar-bottom * {';
			$element_style .= 'color:' . $style_color . '!important;';
		$element_style .= '}';

		$params_class = '';
		if ( isset( $item['params']['class'] ) ) $params_class = $item['params']['class'];

		self::add_editor_style( $element_style );

		?>

		<div class="composer-item <?php echo $item['type']; ?> <?php echo $params_class; ?>" composer-item-type="<?php echo $item['type']; ?>" composer-item-title="<?php echo $elements[ $item['type'] ]['title']; ?>" composer-item-icon="<?php echo $elements[ $item['type'] ]['icon']; ?>">
		
			<div class="composer-item-bg"></div>
			
			<div class="composer-item-toolbar">

				<div class="composer-item-move composer-item-handlebar"></div>

				<div class="composer-item-toolbar-left">
						<span class="composer-item-icon composer-bt <?php if ( $elements[ $item['type'] ]['icon'] ) { echo $elements[ $item['type'] ]['icon']; } else { echo 'no-icon'; } ?>"></span>
						<span class="composer-item-title"><?php echo $elements[ $item['type'] ]['title']; ?></span>

						<?php

						if ( isset( $item['options'] ) ){
							foreach ( $item['options'] as $option_key => $option_value) {
								if ( !is_array($option_value) ) $elements[ $item['type'] ]['infos'] = str_replace( '{{' . $option_key . '}}', $option_value, $elements[ $item['type'] ]['infos'] );
							}
						}
						$elements[ $item['type'] ]['infos'] = preg_replace( '({{.*?}})', '', $elements[ $item['type'] ]['infos'] );

						?>

						<span class="composer-item-infos"><?php echo $elements[ $item['type'] ]['infos']; ?></span>

				</div>

				<div class="composer-item-toolbar-right">

					<div class="composer-item-toolbar-actions">

						<?php if( in_array( 'sort', $editor['options']['actions'] ) ) echo '<div class="composer-item-move composer-bt fa fa-arrows ui-sortable-handle"></div>'; ?>
						<?php if( in_array( 'clone', $editor['options']['actions'] ) ) echo '<div class="composer-item-clone composer-bt fa fa-clone"></div>'; ?>
						<?php if( in_array( 'delete', $editor['options']['actions'] ) ) echo '<div class="composer-item-delete composer-bt fa fa-trash-o"></div>'; ?>
						<?php if( in_array( 'edit', $editor['options']['actions'] ) ) echo '<div class="composer-item-edit composer-bt fa fa-pencil"></div>'; ?>
						
					</div>

					<div class="composer-item-tools-button composer-bt composer-bt-light fa fa-ellipsis-h"></div>

				</div>

			</div>

		<?php

	}

	static function render_editor_element_footer( $item, $type, $title, $icon, $options, $contents, $elements, $editor ) {

		?>

			<textarea style="display:none" class="composer-item-value" type="textarea" autocorrect="off" autocomplete="off" spellcheck="false" placeholder=""><?php echo  json_encode( $item, JSON_UNESCAPED_UNICODE ); ?></textarea>

		</div>

		<?php

	}

	static function render_contents( $type, $contents, $params, $composer, $editor, $preview = false ) {

		$params_defaults = array(
			'sortable' => true,
			'add_button_pos' => '',
			'placeholder' => true,
			'class' => '',
		);

		$params = array_merge( $params_defaults, $params );

		$class = $type . '-contents';
		if ( $params['sortable'] == true ) $class  .= ' composer-items-sortable';
		if ( $params['class'] ) $class .= ' ' . $params['class'];
		if ( $params['add_button_pos'] ) $class  .= ' composer-items-button-' . $params['add_button_pos'];

		?>

		<div class="composer-items <?php echo $class; ?>">

			<?php if ( $params['placeholder'] ) { ?>
				<div class="composer-item-empty"></div>
			<?php } ?>

			<?php handypress_composer::render_elements( $contents, $composer, $editor, $preview ); ?>
			
			<div class="composer-item-toolbar-bottom">
				<div class="composer-item-add-content composer-bt fa fa-plus"></div>
			</div>
			
		</div>

		

	 <?php

	}

	static function render_editor_header( $items, $elements, $editor, $preview = false ) {

		wp_enqueue_script('jquery-ui-sortable');

		wp_enqueue_style( 'handypress-composer', str_replace( WP_CONTENT_DIR, WP_CONTENT_URL,  dirname( __FILE__ ) ) . '/composer.css', false, false, 'screen' );
		wp_enqueue_script('handypress-composer', str_replace( WP_CONTENT_DIR, WP_CONTENT_URL,  dirname( __FILE__ ) ) . '/composer.js', array('jquery'), '1.0', true );

		wp_localize_script( 'handypress-composer', 'handypress_composer_settings', array(
			'editurl' => str_replace( WP_CONTENT_DIR, WP_CONTENT_URL,  dirname( __FILE__ ) ) . '/block-editor.php',
			'ajaxurl' => admin_url( 'admin-ajax.php' ),
			'adminurl' => admin_url()
		));

		wp_enqueue_style( 'bootstrap-4.0.0-grid-composer', str_replace( WP_CONTENT_DIR, WP_CONTENT_URL, dirname( __FILE__ ) ) . '/css/bootstrap-grid-composer.css', false, false, 'screen' );

		?>

		<div class="composer-editor" composer-id="<?php echo $editor['path']; ?>" composer-item-type="<?php echo $editor['options']['type']; ?>" style="visibility:hidden;">

			<div class="composer-editor-scroll">

				<?php if ( $editor['options']['toolbar'] ){ ?>

					<div class="composer-toolbar-top">

						<div class="composer-toolbar-left">

							<span class="composer-actions composer-bt dashicons dashicons-editor-table"></span>
							<span class="composer-action-undo composer-bt fa fa-undo"></span>
							<span class="composer-action-repeat composer-bt fa fa-repeat"></span>
							<!-- <span class="composer-action-add composer-bt fa fa-plus"></span> -->
						</div>

						<div class="composer-toolbar-right">
							<!-- <span class="composer-action-preview composer-bt fa fa-eye"></span> -->
							<!-- <span class="composer-action-xray composer-bt fa fa-low-vision"></span> -->
							<span class="composer-action-source composer-bt fa fa-code"></span>
							<span class="composer-action-debug composer-bt fa fa-bug"></span>
							<span class="composer-action-fullscreen composer-bt fa fa-arrows-alt"></span>
						</div>

					</div>

				<?php } ?>

				<div class="composer-layout">

					<div class="composer-items composer-items-sortable">

	<?php

	}

	static function render_editor_footer( $items, $elements, $editor, $preview = false ) {

		?>

					</div>

					<?php

					if ( $editor['options']['empty'] !== false ){

						?>

						<div class="composer-empty" style="display:none;">

							<?php if ( is_string($editor['options']['empty']) && $editor['options']['empty'] !== '' ){ ?>
								<?php echo $editor['options']['empty']; ?>
							<?php } else { ?>

								<div style="padding:80px 0px;">
									<h1>Add Elements</h1>
								</div>

							<?php } ?>

						</div>

						<?php

					}

					?>

					<div class="composer-toolbar-bottom">

		        <div class="composer-add-items-quick">

		          <ul>

		             <li class="composer-add-item-quick">

		              <!-- <div class="composer-row-add button-secondary" >ADD ROW</div> <div class="composer-preset-add button-secondary" >ADD PRESET</div> -->

		              <span class="composer-item-add-content composer-item-add-root composer-bt fa fa-plus"></span>

		              <!-- <span class="composer-row-add composer-bt fa fa-plus"></span> -->

		            </li>

		          </ul>

		        </div>

		      </div>

		      <?php self::render_modal_edit( ); ?>

		      <?php self::render_modal_items( $items, $elements, $editor, $preview ); ?>

					<div class="composer-source" style="">
					
					<?php 
					if ( $editor['value'] ) $editor['value'] = json_encode( $editor['value'], JSON_UNESCAPED_UNICODE ); 
					?>

		        	<textarea name="<?php echo $editor['id']; ?>" id="<?php echo $editor['id']; ?>" class="wp-field-value meta-field" type="textarea" autocorrect="off" autocomplete="off" spellcheck="false" placeholder="" /><?php echo $editor['value']; ?></textarea>
		      </div>

		      <textarea style="display: none;" class="wp-field-options" type="textarea" autocorrect="off" autocomplete="off" spellcheck="false" placeholder=""/><?php echo json_encode( $editor['options'], JSON_UNESCAPED_UNICODE ); ?></textarea>

		      <script class="composer-template-item" type="text/template"><?php include dirname( __FILE__ ) . '/composer-template-item.php'; ?></script>

				</div>

			</div>

		</div>

		<?php

		self::render_editor_style();

	}

	static function add_editor_style( $style = '' ) {

		self::$EDITOR_STYLE .= $style;

	}

	static function render_editor_style() {

		echo '<style>' . self::$EDITOR_STYLE . '</style>';

	}

	static function render_modal_edit( ) {

		echo '<div class="composer-modal-edit composer-modal">';

			echo '<div class="composer-modal-bg composer-modal-close"></div>';

		 	echo '<div class="composer-modal-container">';

		    	echo '<div class="composer-modal-toolbar-top">';

		      		echo '<div class="composer-modal-toolbar-left">';

		      			echo '<span class="composer-modal-toolbar-title">Title</span>';

		      		echo '</div>';

		      		echo '<div class="composer-modal-toolbar-right">';

		      			echo '<span class="composer-modal-close composer-bt dashicons dashicons-no"></span>';

		      		echo '</div>';

		    	echo '</div>';

		    	echo '<div class="composer-modal-content">';

					echo '<iframe width="100%" id="composer-iframe-edit" name="composer-iframe-edit" src=""></iframe>';

					echo '<span class="spinner spinner-center"></span>';

				echo '</div>';

			echo '</div>';

		echo '</div>';

	}

	static function render_modal_items( $items, $elements, $editor, $preview = false ) {

		echo '<div class="composer-modal-add composer-modal">';

			echo '<div class="composer-modal-bg composer-modal-close"></div>';

		 	echo '<div class="composer-modal-container">';

		    	echo '<div class="composer-modal-toolbar-top">';

		      		echo '<div class="composer-modal-toolbar-left">';

		      			echo '<span class="composer-modal-toolbar-title">Add Elements</span>';

		      		echo '</div>';

		      		echo '<div class="composer-modal-toolbar-right">';

		      			echo '<span class="composer-modal-close composer-bt dashicons dashicons-no"></span>';

		      		echo '</div>';

		    	echo '</div>';

		    	echo '<div class="composer-modal-content">';

					echo '<div class="composer-add-items row no-gutters">';

						$elements_allow_rules = array();
						

						if ( $elements ) {
							
							foreach ( $elements as $element_key => $item ) {

								
								$elements_allow_rules[ $element_key ]['title'] = $item['title'];

								if ( $item['parent'] ) {

									$parent_arr = explode( ',', $item['parent'] );

									foreach ( $parent_arr as $parent ) {

										$elements_allow_rules[ $element_key ]['parent'][] = $parent;

									}

								} else {

									$elements_allow_rules[ $element_key ]['parent'] = 'all';

								}

								if ( $item['accept'] ) {

									$accept_arr = explode( ',', $item['accept'] );

									foreach ( $accept_arr as $accept ) {

										$elements_allow_rules[ $element_key ]['accept'][] = $accept;

									}

								} else {

									$elements_allow_rules[ $element_key ]['accept'] = 'all';

								}

								//
								// $accept_classes = '';
								//
								// if ( $item['accept'] ) {
								//
								// 	$accept_arr = explode( ',', $item['accept'] );
								//
								// 	foreach ( $accept_arr as $accept ) {
								//
								// 		$accept_classes .= ' .composer-accept-only-element_' . $accept;
								//
								// 	}
								//
								// } else {
								//
								// 	$accept_classes = '.composer-accept-only-all';
								//
								// }

								$parent = '';
								if( isset( $item['parent'] ) && is_array( $item['parent'] ) ) $parent = implode( ',', $item['parent'] );
								
								$accept = '';
								if( isset( $item['accept'] ) && is_array( $item['accept'] ) ) $accept = implode( ',', $item['accept'] );

								echo '<div id="' . $element_key . '" class="composer-add-item composer-item-add col-12 col-md-6 col-lg-4" composer-item-type="' . $element_key . '" composer-item-title="' . $item['title'] . '" composer-item-icon="' . $item['icon'] . '" composer-item-parent="' . $parent . '" composer-item-accept="' . $accept . '" >';

									echo '<div class="composer-add-item-content">';

										echo '<div class="composer-add-item-bottom-left">';

											if( ! isset( $item['icon'] ) ) $item['icon'] = 'fa fa-cube';
											echo '<div class="composer-item-title"><span class="' . $item['icon'] . '"></span> ' . $item['title'] . '</div>';
											echo '<div class="composer-item-desc">' . $item['desc'] . '</div>';

										echo '</div>';

										echo '<div class="composer-add-item-bottom-right">';

											//echo '<span class="composer-item-add composer-bt fa fa-plus"></span>';
											//echo '<div class="composer-item-add button">ADD</div>';

										echo '</div>';

									echo '</div>';

									//create element settings
									$element_data = array( 'type' => $element_key, 'options' => array(), 'contents' => array() );

									if ( $item['options'] ){
										foreach ( $item['options'] as $option_id => $option ) {

											if ( isset( $option['default'] ) && $option['default'] !== "" ) {
												$element_data['options'][ $option_id ] = $option['default'];
											} else {
												$element_data['options'][ $option_id ] = '';
											}

										}
									}
									
									$template = '';

									ob_start();

										if ( isset( $elements[ $element_data['type'] ] ) ) {

											if ( $editor ) {

												if ( isset( $elements[ $element_data['type'] ]['editor'] ) && is_callable( $elements[ $element_data['type'] ]['editor'] ) ) {

													call_user_func( $elements[ $element_data['type'] ]['editor'], $element_data, $element_data['type'], $elements[ $element_data['type'] ]['title'], $elements[ $element_data['type'] ]['icon'], $element_data['options'], $element_data['contents'], $elements, $editor, $preview );

												} else {

						              				handypress_composer::render_editor_element( $element_data, $element_data['type'], $elements[ $element_data['type'] ]['title'], $elements[ $element_data['type'] ]['icon'], $element_data['options'], $element_data['contents'], $elements, $editor, $preview );

						            			}

											}

										}

						      	$template = ob_get_contents();

						      ob_end_clean();

									echo '<script class="composer-template-item" type="text/template">' . $template . '</script>';

								echo '</div>';

							}

						}

						echo '<script type="text/javascript">
						/* <![CDATA[ */
						var handypress_composer_elements_allow = ' . json_encode( $elements_allow_rules ) . ';
						/* ]]> */
						</script>';

						// _HANDYLOG( $elements_allow_rules );

						echo '</div>';

					echo '</div>';

				echo '</div>';

			echo '</div>';

		}

	}

}

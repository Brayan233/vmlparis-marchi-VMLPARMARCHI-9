<div class="composer-block">

	<div class="composer-block-over"></div>

	<div class="composer-block-tools">

		<div class="composer-block-toolbar">

			<div class="composer-block-move composer-block-handlebar ui-sortable-handle"></div>

			<div class="composer-block-toolbar-left">

				<div class="composer-info composer-block-type">Block</div> <div class="composer-info composer-block-title"></div>

				<div class="composer-info">
					<span class="composer-block-bg-color" style="background-color:"></span>
				</div>

			</div>

			<div class="composer-block-toolbar-right">

				<div class="composer-block-toolbar-actions">

					<div class="composer-block-move composer-bt fa fa-arrows-v ui-sortable-handle"></div>

					<div class="composer-block-clone composer-bt fa fa-clone"></div>

					<div class="composer-block-delete composer-bt fa fa-trash-o"></div>

					<div class="composer-block-edit composer-bt fa fa-pencil"></div>

				</div>

				<div class="composer-block-tools-button composer-bt composer-bt-light fa fa-ellipsis-h"></div>

			</div>

		</div>

	</div>

	<textarea style="display:none;width:100%;" class="composer-block-value"></textarea>

	<div class="composer-block-preview"></div>

</div>

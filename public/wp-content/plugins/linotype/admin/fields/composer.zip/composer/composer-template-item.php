<div class="composer-item" composer-item-type="">

	<div class="composer-item-toolbar">

		<div class="composer-item-move composer-item-handlebar ui-sortable-handle"></div>

			<div class="composer-item-toolbar-left">
				<span class="composer-item-icon composer-bt"></span>
				<span class="composer-item-title"></span>
			</div>

		<div class="composer-item-toolbar-right">

			<div class="composer-item-toolbar-actions">

				<div class="composer-item-move composer-bt fa fa-arrows ui-sortable-handle"></div>
 				<div class="composer-item-clone composer-bt fa fa-clone"></div>
 				<div class="composer-item-delete composer-bt fa fa-trash-o"></div>
 				<div class="composer-item-edit composer-bt fa fa-pencil"></div>

			</div>

			<div class="composer-item-tools-button composer-bt composer-bt-light fa fa-ellipsis-h"></div>

		</div>

	</div>

  <textarea style="display:none" class="composer-item-value"></textarea>

</div>

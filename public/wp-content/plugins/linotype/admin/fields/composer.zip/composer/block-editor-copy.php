<?php

global $WPBLOCKS_EDITOR;

require_once( dirname(dirname(dirname(dirname(dirname(dirname( __FILE__ )))))) . '/wp-admin/admin.php' );

if ( ! isset( $_REQUEST['id'] ) && ! $_REQUEST['id'] ) {
  wp_die( '<h1>' . __( 'Cheatin&#8217; uh?' ) . '</h1>' . '<p>' . 'blocks:error:composer:001' . '</p>', 403 );  
}
switch( $_REQUEST['composer_type'] ) {

  case 'block':
    $WPBLOCKS_EDITOR['data'] = WPBLOCKS::$BLOCKS->get($_REQUEST['id']);
  break;
  
  case 'field':
    $fields = WPBLOCKS_helpers::get_element_options();
    $WPBLOCKS_EDITOR['data'] = $fields[$_REQUEST['id']];
  break;

}




// _HANDYLOG($_REQUEST['id']);
// $registered = $wp_scripts->registered;
// $wp_scripts = new WP_Scripts;
// $wp_scripts->registered = $registered;

//wp_enqueue_script( 'customize-controls' );
// wp_enqueue_style( 'customize-controls' );
  
@header('Content-Type: ' . get_option('html_type') . '; charset=' . get_option('blog_charset'));

wp_user_settings();
_wp_admin_html_begin();

wp_enqueue_style( 'colors' );
wp_enqueue_style( 'ie' );
wp_enqueue_script('utils');
wp_enqueue_script( 'svg-painter' );
wp_enqueue_style( 'composer-iframe', str_replace( WP_CONTENT_DIR, WP_CONTENT_URL, dirname( __FILE__ ) ) . '/composer-iframe.css', false, false, 'screen' );

$body_class = 'wp-core-ui js wpblocks wpblocks-editor ' . get_option('blocks_editor_dark','blocks-editor-light' );

if ( wp_is_mobile() ) :
	$body_class .= ' mobile';
	?><meta name="viewport" id="viewport-meta" content="width=device-width, initial-scale=1.0, minimum-scale=0.5, maximum-scale=1.2" /><?php
endif;

if ( is_rtl() ) {
	$body_class .= ' rtl';
}

$body_class .= ' locale-' . sanitize_html_class( strtolower( str_replace( '_', '-', get_user_locale() ) ) );

$admin_title = '';

?><title><?php echo $admin_title; ?></title>

<script type="text/javascript">
var ajaxurl = <?php echo wp_json_encode( admin_url( 'admin-ajax.php', 'relative' ) ); ?>;
</script>

<?php

do_action( 'wpblocks_editor_print_styles' );
do_action( 'wpblocks_editor_print_scripts' );

global $hook_suffix;

do_action( 'admin_enqueue_scripts', $hook_suffix );

  do_action( "admin_print_styles-{$hook_suffix}" );

  do_action( 'admin_print_styles' );

  do_action( "admin_print_scripts-{$hook_suffix}" );

  do_action( 'admin_print_scripts' );

  do_action( "admin_head-{$hook_suffix}" );

  do_action( 'admin_head' );

?>

</head>

<body class="<?php echo esc_attr( $body_class ); ?>">

<?php

//$BLOCKS = WPBLOCKS::$BLOCKS->get();

$items = array();

// if ( isset( $BLOCKS[ $_REQUEST['id'] ] ) ) {

//   $FIELD = $BLOCKS[ $_REQUEST['id'] ];

  $data = json_decode( stripslashes( get_option( 'handypress_composer_temp_settings' ) ), true );

//   if ( is_callable( $FIELD['options']['items'] ) ) {

//     $items = call_user_func( $FIELD['options']['items'] );

//   } else {

//     $items = $FIELD['options']['items'];

//   }

// }

$item = $WPBLOCKS_EDITOR['data'];

$tabs = array();

// _HANDYLOG('items',$items);

//order by tab
if( isset( $item['options'] ) ){
  foreach ( $item['options'] as $field_id => $field ) {

    if ( ! isset( $field['tab'] ) ){
      $tabs[ 'General' ][ $field_id ] = $field;
    } else {
      $tabs[ $field['tab'] ][ $field_id ] = $field;
    }

  }
}

//print
echo '<div class="ADMINBLOCKS-tab" data-tab-style="nav">';

  $tab_id = 0;

  if( isset( $tabs ) && count( $tabs ) > 1 ){

    echo '<div class="wp-filter"><ul class="ADMINBLOCKS-tab-nav filter-links">';

    foreach ( $tabs as $tab_title => $tab ) {

        if ( $tab_id == 0 ){
          $state = ' current';
        } else{
          $state = '';
        };

        echo '<li id="tab-' . $tab_title . '"><a id="tab_' . $tab_id . '-ADMINBLOCKS-tab-nav-id" class="ADMINBLOCKS-tab-nav-item' . $state . '" href="#content_' . $tab_id . '" >' . $tab_title . '</a></li>';

        $tab_id++;

    }

    echo '</ul></div>';

  }

  $content_id = 0;

  if( isset( $tabs ) ){

    echo '<div class="ADMINBLOCKS-tab-content">';

      foreach ( $tabs as $tab_title => $tab ) {

        $state = '';
        if ( $content_id == 0 ) $state .= ' content-tab-active';

        echo '<div id="content_' . $content_id . '-ADMINBLOCKS-tab-content-id" class="ADMINBLOCKS-tab-content-item' . $state . '">';

          echo '<div class="container-fullwidth">';
          echo '<div class="row no-gutters">';

            if( isset( $tab ) ){
              foreach ( $tab as $field_id => $field ) {

                $field['id'] = $field_id;

                if ( isset( $data['options'][ $field['id'] ] ) ) {

                  $field['value'] = $data['options'][ $field['id'] ];

                } else {

                  $field['value'] = "";

                }

                if ( isset( $field['options']['placeholder'] ) && $field['default'] != "" ) {

                  $field['options']['placeholder'] = $field['default'];

                  if ( isset( $field['options']['data'] ) && $field['options']['data'] ) {
                    foreach ( $field['options']['data'] as $options_data_key => $options_data ) {

                      if ( $options_data['value'] == $field['default'] ) $field['options']['placeholder'] =  $options_data['title'];

                    }

                  }

                }

                //if ( $field['type'] == 'json' ) _HANDYLOG($field['options']['data']);

                if ( is_dir( $field['type'] ) ) {

                  $field_type = explode('/', $field['type'] );
                  $field_type = end( $field_type );

                  if ( file_exists( $field['type'] . '/' . $field_type . '.php' ) ) {

                    if ( ! $field['col'] ) $field['col'] = "col-12";

                    echo '<div class="'. $field['col'] .'">';

                      include $field['type'] . '/' . $field_type . '.php';

                    echo '</div>';

                  }

                } else if ( file_exists( WP_CONTENT_DIR . '/plugins/blocks/admin/fields/' . $field['type'] . '/' . $field['type'] . '.php' ) ) {

                    if ( ! $field['col'] ) $field['col'] = "col-12";
                    if ( ! $field['options'] ) $field['options'] = array();

                    echo '<div class="'. $field['col'] .'">';

                        include WP_CONTENT_DIR . '/plugins/blocks/admin/fields/' . $field['type'] . '/' . $field['type'] . '.php';

                    echo '</div>';

                } else {

                  echo $field['type'];
                  
                }

                if ( isset( $field['help'] ) && $field['help'] === true ) { echo '<pre>'; var_dump($field); echo '</pre>'; }

              }
            }

            echo '</div>';
            echo '</div>';

          $content_id++;

        echo '</div>';

      }

    echo '</div>';

  }

echo '</div>';

echo '<div class="composer-modal-toolbar-inner">';

  echo '<div class="composer-modal-toolbar-inner-left"><textarea style="display:none" class="composer-modal-item-infos" type="textarea" autocorrect="off" autocomplete="off" spellcheck="false" placeholder="">' . $item['infos'] . '</textarea></div>';
  echo '<div class="composer-modal-toolbar-inner-right"><div class="composer-modal-close button button-large button-error">Cancel</div> <div class="composer-item-save button button-large button-success">OK</div></div>';

echo '</div>';

?>

<?php 

do_action( 'admin_footer', '' );

do_action( "admin_print_footer_scripts-{$hook_suffix}" );

do_action( 'admin_print_footer_scripts' );

do_action( "admin_footer-{$hook_suffix}" );

do_action( 'wpblocks_editor_print_footer_scripts' ); ?>

<script type="text/javascript">if(typeof wpOnload=='function')wpOnload();</script>
</body>
</html>

<?php

$path = preg_replace('/wp-content(?!.*wp-content).*/','',__DIR__);

include($path.'wp-load.php');

@header('Content-Type: ' . get_option('html_type') . '; charset=' . get_option('blog_charset'));

require_once( $path . 'wp-admin/admin.php' );

// die('cool');
  //include dirname( __FILE__ ) . '/composer-header.php';
  //require_once( ABSPATH . 'wp-admin/admin-header.php' );
  do_action( 'admin_print_styles' );
do_action( 'admin_print_scripts' );


  //add_action( 'init', function(){

//  die('cool');
    _HANDYLOG('add_action');
    add_thickbox();
    wp_enqueue_media();



  remove_action( 'wp_head', 'print_emoji_detection_script' );
  remove_action( 'wp_print_styles', 'print_emoji_styles' );
  remove_action( 'admin_print_scripts', 'print_emoji_detection_script' );
  remove_action( 'admin_print_styles', 'print_emoji_styles' );
  remove_action( 'embed_head',             'print_emoji_detection_script'          );


  global $ADMINBLOCKS;

  $items = array();

  if ( isset( $ADMINBLOCKS[ $_REQUEST['composer_id'] ] ) ) {


    $FIELD = $ADMINBLOCKS[ $_REQUEST['composer_id'] ];

    $data = json_decode( stripslashes( get_option( 'handypress_composer_temp_settings' ) ), true );

    if ( is_callable( $FIELD['options']['items'] ) ) {

      $items = call_user_func( $FIELD['options']['items'] );

    } else {

      $items = $FIELD['options']['items'];

    }

  }

  $tabs = array();

  //order by tab
  if( isset( $items[ $data['type'] ]['options'] ) ){
    foreach ( $items[ $data['type'] ]['options'] as $field_id => $field ) {

      if ( ! isset( $field['tab'] ) ){
        $tabs[ 'General' ][ $field_id ] = $field;
      } else {
        $tabs[ $field['tab'] ][ $field_id ] = $field;
      }

    }
  }

  //print
  echo '<div class="ADMINBLOCKS-tab" data-tab-style="nav">';

    $tab_id = 0;

    if( isset( $tabs ) && count( $tabs ) > 1 ){

      echo '<div class="wp-filter"><ul class="ADMINBLOCKS-tab-nav filter-links">';

      foreach ( $tabs as $tab_title => $tab ) {

          if ( $tab_id == 0 ){
            $state = ' current';
          } else{
            $state = '';
          };

          echo '<li><a id="tab_' . $tab_id . '-ADMINBLOCKS-tab-nav-id" class="ADMINBLOCKS-tab-nav-item' . $state . '" href="#content_' . $tab_id . '" >' . $tab_title . '</a></li>';

          $tab_id++;

      }

      echo '</ul></div>';

    }

    $content_id = 0;

    if( isset( $tabs ) ){

      echo '<div class="ADMINBLOCKS-tab-content">';

        foreach ( $tabs as $tab_title => $tab ) {

          $state = '';
          if ( $content_id == 0 ) $state .= ' content-tab-active';

          echo '<div id="content_' . $content_id . '-ADMINBLOCKS-tab-content-id" class="ADMINBLOCKS-tab-content-item' . $state . '">';

            echo '<div class="container-fullwidth">';
            echo '<div class="row no-gutters">';

              if( isset( $tab ) ){
                foreach ( $tab as $field_id => $field ) {



                  $field['id'] = $field_id;

                  $field['value'] = $data['options'][ $field['id'] ];

                  if ( $field['value'] == "" && $field['default'] != "" ) {

                    $field['value'] =  $field['default'];

                  }

                  //_HANDYLOG( $field );

                  // if ( $field['options'] == "" && $field['options'] != "" ) {
                  //
                  //   $field['options'] =  json_decode( stripslashes( $field['options'] ), true );
                  //
                  // }


                  if ( is_dir( $field['type'] ) ) {

                    $field_type = explode('/', $field['type'] );
                    $field_type = end( $field_type );

                    if ( file_exists( $field['type'] . '/' . $field_type . '.php' ) ) {

                      if ( ! $field['col'] ) $field['col'] = "col-12";

                      echo '<div class="'. $field['col'] .'">';

                        include $field['type'] . '/' . $field_type . '.php';

                      echo '</div>';

                    }

                  } else {

                    if ( file_exists( WP_CONTENT_DIR . '/plugins/blocks/admin/fields/' . $field['type'] . '/' . $field['type'] . '.php' ) ) {

                      if ( ! $field['col'] ) $field['col'] = "col-12";
                      if ( ! $field['options'] ) $field['options'] = array();

                      echo '<div class="'. $field['col'] .'">';

                        include WP_CONTENT_DIR . '/plugins/blocks/admin/fields/' . $field['type'] . '/' . $field['type'] . '.php';

                      echo '</div>';

                    }

                  }

                  if ( isset( $field['help'] ) && $field['help'] === true ) { echo '<pre>'; var_dump($field); echo '</pre>'; }

                }
              }

              echo '</div>';
              echo '</div>';

            $content_id++;

          echo '</div>';

        }

      echo '</div>';

    }

  echo '</div>';

  echo '<div class="composer-modal-toolbar-inner"><div class="composer-modal-toolbar-inner-left"></div><div class="composer-modal-toolbar-inner-right"><div class="composer-modal-close button button-large button-error">Cancel</div> <div class="composer-item-save button button-large button-success">OK</div></div></div>';

  do_action( 'admin_footer', '' );
  do_action( 'admin_print_footer_scripts' );
  //include dirname( __FILE__ ) . '/composer-footer.php';
  //require_once( ABSPATH . 'wp-admin/admin-footer.php' );

  //die();
//}, 99999999 );

?>

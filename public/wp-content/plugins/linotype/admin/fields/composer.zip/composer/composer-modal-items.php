

<div class="composer-modal" composer-target="">

  <div class="composer-modal-container">

    <div class="composer-modal-toolbar">
      
      <h1>Add Elements</h1>

      <span class="composer-modal-close composer-bt fa fa-close"></span>

    </div>

    <div class="composer-modal-content">

      <div class="composer-add-items">

        <ul>

          <?php if ( isset( $field['options']['data_custom'] ) ) { ?>
            <?php foreach ( $field['options']['data_custom'] as $data_custom_key => $data_custom ) { ?> 

              <?php

              $default_data_custom = array(
                'title' => 'Item',
                'desc' => '',
                'button' => 'Add',
              );

              $data_custom = wp_parse_args( $data_custom, $default_data_custom );
              
              ?>

              <li class="composer-add-item">

                <?php if ( $data_custom['title'] ) { ?><h3><?php echo $data_custom['title']; ?></h3><?php } ?>
                   
                <?php if ( $data_custom['desc'] ) { ?><p><?php echo $data_custom['desc']; ?></p><?php } ?>
                        
                <div class="composer-add-item-button button-secondary" data-fields='<?php echo json_encode( $data_custom["fields"] ); ?>' ><?php echo $data_custom['button']; ?></div>

              </li>
                  
            <?php } ?>

          <?php } ?>

        </ul>

      </div>

    </div>

  </div>

</div>

<div class="composer-row" composer-row-type="default">

	<div class="composer-row-tools">

		<div class="composer-row-toolbar">

			<div class="composer-row-move composer-row-handlebar ui-sortable-handle"></div>

			<div class="composer-row-toolbar-left">

				<div class="composer-info composer-row-title">row</div>

				<div class="composer-info">
					<span class="composer-row-bg-color" style="background-color:"></span>
				</div>

			</div>

			<div class="composer-row-toolbar-right">

				<div class="composer-row-toolbar-actions">

					<div class="composer-row-move composer-bt fa fa-arrows-v ui-sortable-handle"></div>

					<div class="composer-row-clone composer-bt fa fa-clone"></div>

					<div class="composer-row-delete composer-bt fa fa-trash-o"></div>

					<div class="composer-row-edit composer-bt fa fa-pencil"></div>

				</div>

				<div class="composer-row-tools-button composer-bt composer-bt-light fa fa-ellipsis-h"></div>

			</div>

		</div>

	</div>

	<textarea style="display:none;width:100%;" class="composer-row-value">{"_type":"default","title":"row","type":"","gutters":"true","justify":"","align":"","hidden-up":"","hidden-down":"","display":"","id":"","class":"","max-width":"","background-color":"","background-image":"","margin":"","padding":"","container-bg-color":"","wrapper-bg-color":""}</textarea>


	<div class="wrapper" style="">

		<div class="composer-wrapper-margin"><div class="composer-wrapper-padding">

			<div class="container" style="">

				<div class="row composer-row-content ui-sortable" style="">



						<div class="composer-column col" style="" composer-column-type="default">

							<div class="composer-column-padding-top"></div>
							<div class="composer-column-padding-left"></div>
							<div class="composer-column-padding-right"></div>
							<div class="composer-column-padding-bottom"></div>

							<div class="composer-column-inner">

								<div class="composer-column-tools absolute">

									<div class="composer-column-toolbar">

										<div class="composer-column-move composer-column-handlebar ui-sortable-handle"></div>

										<div class="composer-column-toolbar-left">

											<div class="composer-info composer-column-title">column</div>

										</div>

										<div class="composer-column-toolbar-right">

											<div class="composer-column-toolbar-actions">

												<div class="composer-column-move composer-bt fa fa-arrows-h ui-sortable-handle"></div>

												<div class="composer-column-clone composer-bt fa fa-clone"></div>

												<div class="composer-column-delete composer-bt fa fa-trash-o"></div>

												<div class="composer-column-edit composer-bt fa fa-pencil"></div>

											</div>

											<div class="composer-column-tools-button composer-bt composer-bt-light fa fa-ellipsis-h"></div>

										</div>

									</div>



								</div>

								<textarea style="display:none;width:100%;" class="composer-column-value">{"_type":"default","title":"column","col":"","col-sm":"","col-md":"","col-lg":"","col-xl":"","clearfix":"","align":"","offset":"","hidden-up":"","hidden-down":"","display":"","id":"","class":"","max-width":"","background-color":"","background-image":"","margin":"","padding":""}</textarea>


								<div id="composer-row_0-col_0" class="composer-items ui-sortable" style="">

									<div class="composer-item-empty"></div>


								</div>

								<div class="composer-column-tools-bottom">

									<span class="composer-modal-add-bt composer-bt fa fa-plus"></span>

								</div>

							</div>

						</div>



				</div>

			</div>

		</div></div>

	</div>

</div>

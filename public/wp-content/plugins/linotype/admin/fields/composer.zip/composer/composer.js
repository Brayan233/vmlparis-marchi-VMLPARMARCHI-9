(function($) {

$.fn.wp_field_composer = function(){

	$(this).each(function(){

		var $FIELD = $(this);

		var $VALUE = $FIELD.find('.wp-field-value');

		var $OPTIONS = $.parseJSON( $FIELD.find('.wp-field-options').val() );

		var $COMPOSER = $FIELD.find('.composer-editor');

		var $COMPOSER_ROWS = $COMPOSER.find('.composer-layout > .composer-items');

		var $COMPOSER_ID = $COMPOSER.attr('composer-id');

		var $COMPOSER_ITEM_TYPE = $COMPOSER.attr('composer-item-type');

		var $MODAL_EDIT = $FIELD.find('.composer-modal-edit');

		var $MODAL_ADD = $FIELD.find('.composer-modal-add');

		var $PREVIEW = $FIELD.find('.composer-preview');

		var $HISTORY = [];

		var $HISTORY_current = 0;

		var $COPY = "";

		/*
		 *
		 * sortable_items
		 *
		*/


		function sortable_items() {

			var $ui_item_source_parent;

			$(".composer-items.composer-items-sortable").sortable({

				connectWith: '.composer-items.composer-items-sortable',
				items: "> .composer-item",
				opacity: 0.5,
		    	placeholder: 'composer-item-placeholder',
				//helper: "clone",
		    	revert: false,
    			revertDuration: 0,
		    	handle: ".composer-item-move",
				// forcePlaceholderSize:true,
		    	// forceHelperSize: true,
				dropOnEmpty: true,
		    	tolerance: "pointer",

				appendTo: 'body',
				// containment: "window",
				// cursorAt: {top: 0, left: 0},
				//axis: "x",

		    start: function(e, ui){

					//ui.placeholder.css('visibility', 'visible');
					//ui.placeholder.height( ui.item.outerHeight() -1 );

					//ui.item.width(  ui.placeholder.outerWidth()  -1 );
					ui.item.css('opacity', '.5');
					ui.item.show();

					$ui_item_source_parent = ui.item.parent().closest('.composer-item');

		    },
				sort: function (e, ui) {

					//ui.placeholder.css('visibility', 'visible');

					ui.item.css('opacity', '.5');
					ui.item.show();

		    },
		    change: function(event, ui) {

	        	//ui.placeholder.height( ui.item.outerHeight() -1 );
				//ui.placeholder.css('visibility', 'visible');

				//ui.item.width(  ui.placeholder.outerWidth()  -1 );
				ui.item.css('opacity', '.5');
				ui.item.show();

		    },
		    stop: function(e, ui) {

				ui.item.css('opacity', '1');

		        $(".composer-item").css('z-index', 0 );

				$('body').trigger('composer-sort', $ui_item_source_parent );
				$('body').trigger('composer-sort', ui.item.parent().closest('.composer-item') );

		    }
			});

		}

		//sortable_rows();
		sortable_items();


		/*
		 *
		 * open_modal_add
		 *
		*/
		var $current_item_target;

		function open_modal_add(){

			$allowed_items = [];
			console.log(handypress_composer_elements_allow);
			$.each( handypress_composer_elements_allow, function( index, element_id ){

				$allowed_items.push( index );

			});

			if( $(this).hasClass('composer-item-add-root') ) {

			 	$current_item_target = $(this).closest('.composer-layout').find( '> .composer-items' );

				$.each( $allowed_items, function( index, element_id ) {

					if ( handypress_composer_elements_allow[ element_id ]['parent'] == 'all' ) {

					} else {

						$allowed_items = removeFromArray( element_id, $allowed_items );

					}

				});

			} else {

				$current_item_target = $(this).closest('.composer-items');

				$current_item_type = $(this).closest('.composer-item').attr('composer-item-type');
				$current_item_parent_type = $(this).closest('.composer-item').parent().closest('.composer-item').attr('composer-item-type');
				if ( ! $current_item_parent_type ) $current_item_parent_type = 'root';

				$.each( $allowed_items, function( index, element_id ) {

					if ( handypress_composer_elements_allow[ element_id ]['parent'] == 'all' ) {

					} else if ( $current_item_parent_type !== 'root' && ! jQuery.inArray( $current_item_parent_type, handypress_composer_elements_allow[ element_id ]['parent'] ) ) {

						$allowed_items = removeFromArray( element_id, $allowed_items );

					} else if( $current_item_parent_type == 'root' ) {

						$allowed_items = removeFromArray( element_id, $allowed_items );

					}

				});

				if ( handypress_composer_elements_allow[ $current_item_type ]['accept'] === 'all' ) {

				} else {

					$allowed_items = [];

					$.each( handypress_composer_elements_allow[ $current_item_type ]['accept'], function( index, element_id ){

						$allowed_items.push( element_id );

					});

				}

			}

			$MODAL_ADD.find('.composer-add-item').removeClass('active');

			$.each( $allowed_items, function( index, element_id ){

				$( '#' + element_id ).addClass('active');

			});

			if ( $MODAL_ADD.find('.composer-add-item.active').length == 1 ) {

				add_item_single( $MODAL_ADD.find('.composer-add-item.active') );

			} else {

				$MODAL_ADD.addClass('show');

			}



		}


		/*
		 *
		 * add_item
		 *
		*/
		function add_item(e) {

			$this = $(this).closest('.composer-add-item');

			$target = $MODAL_ADD.attr('composer-target');

			$model = $( $this.find('.composer-template-item')[0].innerText );

			$clone = $model.clone();

			$item_default_type = $this.attr('composer-item-type');
			$item_default_title = $this.attr('composer-item-title');
			$item_default_icon = $this.attr('composer-item-icon');
			if ( ! $item_default_icon ) $item_default_icon = 'no-icon';

			$clone.attr('composer-item-type', $item_default_type );
			$clone.attr('composer-item-title', $item_default_title );
			$clone.attr('composer-item-icon', $item_default_icon );

			$clone.find('.composer-item-title').text( $item_default_title );
			$clone.find('.composer-item-icon').attr('class', 'composer-item-icon composer-bt ' + $item_default_icon );
			$clone.find('.composer-item-value').val( '{"type":"' + $item_default_type + '"}' );

			$clone.appendTo( $current_item_target ).hide().fadeIn(500);

			$('body').trigger('composer-add', $($current_item_target).parent().closest('.composer-item') );

			close_modal_add();

		}


		/*
		 *
		 * add_item_single
		 *
		*/
		function add_item_single( $this ) {

			$target = $MODAL_ADD.attr('composer-target');

			$model = $( $this.find('.composer-template-item')[0].innerText );

			$clone = $model.clone();

			$item_default_type = $this.attr('composer-item-type');
			$item_default_title = $this.attr('composer-item-title');
			$item_default_icon = $this.attr('composer-item-icon');
			if ( ! $item_default_icon ) $item_default_icon = 'no-icon';

			$clone.attr('composer-item-type', $item_default_type );
			$clone.attr('composer-item-title', $item_default_title );
			$clone.attr('composer-item-icon', $item_default_icon );

			$clone.find('.composer-item-title').text( $item_default_title );
			$clone.find('.composer-item-icon').attr('class', 'composer-item-icon composer-bt ' + $item_default_icon );
			$clone.find('.composer-item-value').val( '{"type":"' + $item_default_type + '"}' );

			$clone.appendTo( $current_item_target ).hide().fadeIn(500);

			$('body').trigger('composer-add', $($current_item_target).parent().closest('.composer-item') );

		}

		$COMPOSER.on( 'click', '.composer-item-add', add_item ) ;


		/*
		 *
		 * composer_item_edit
		 *
		*/
		var $current_item;

		var $current_item_deep = 0;

		function composer_item_edit(e){

			$current_item_deep++;

			$current_item = {};

			$current_item['this'] = $(this).closest('.composer-item' );
			$current_item['infos'] = $current_item['this'].find('> .composer-item-toolbar > .composer-item-toolbar-left > .composer-item-infos');
			$current_item['value'] = $current_item['this'].find('> .composer-item-value');
			$current_item['settings'] = $current_item['value'].val();

			$current_item['type'] = $current_item['this'].attr('composer-item-type');
			$current_item['title'] = $current_item['this'].attr('composer-item-title');
			$current_item['icon'] = $current_item['this'].attr('composer-item-icon');
			$current_item['settings_array'] = $.parseJSON( $current_item['settings'] );

			$MODAL_EDIT.find('.composer-modal-toolbar-title').text( 'Edit ' + $current_item['title'] ) ;

			$MODAL_EDIT.addClass('show');

			$.ajax({
			 	type : "post",
			 	dataType : "json",
			 	url : handypress_composer_settings.ajaxurl,
			 	data : {
			 		action: "handypress_composer_temp_settings",
					 settings : $current_item['settings'],
					 block_id : $current_item['type']
			 	},
				success: function(response) {

						 if(response.type == "success") {

							var $timestamp = new Date().getUTCMilliseconds();

							var iframe_url = handypress_composer_settings.editurl + '?action=handypress_composer_edit&composer_id=' + $COMPOSER_ID + '&composer_type=' + $COMPOSER_ITEM_TYPE + '&id=' + response.block_id + '&timestamp=' + $timestamp;
							
							//var iframe_url = handypress_composer_settings.ajaxurl + '?action=handypress_composer_edit&composer_id=' + $COMPOSER_ID + '&timestamp=' + $timestamp;

							$MODAL_EDIT.find('iframe').attr('src', iframe_url );

							$MODAL_EDIT.find('iframe').on('load', function(){

								$MODAL_EDIT.find('iframe').contents().on( 'click', '.composer-modal-close', close_modal_add ) ;

								$MODAL_EDIT.find('iframe').contents().on( 'click', '.composer-item-save', composer_item_save ) ;

								$(this).show();

							});

				    } else {

				       console.log("error")

				    }

			 	},

				error: function(response) {
					console.log('error');
				}

			});

		}

		/*
		 *
		 * composer_item_save
		 *
		*/
		function composer_item_save(e){

			var $options = {};

			var item_infos = $MODAL_EDIT.find('iframe').contents().find('.composer-modal-item-infos').val();

			$MODAL_EDIT.find('iframe').contents().find(".wp-field-value").each(function(field_index, field ) {

				$field_id = $(field).attr('id');

				if ( $field_id ) {

					$field_value = $(field).val();
					if( $(field).attr('type') == 'checkbox' && ! $(field).is(':checked') ) $field_value = "";

					if ( $field_value ) {

						try {

						  $options[ $field_id ] = $.parseJSON( $field_value );

						} catch(e) {

							$options[ $field_id ] = $field_value;

						}

					}

					if ( $options[ $field_id ] ) {
						var regex = new RegExp('{{'+$field_id+'}}', "igm");
						item_infos = item_infos.replace(regex, $options[ $field_id ] );
					}

				}

			});

			if ( $options.length !== -1 ) $current_item['settings_array']['options'] = $options;

			var regex = new RegExp('{{.*?}}', "igm");
			item_infos = item_infos.replace(regex, '' );

			$current_item['infos'].html( item_infos );

			$current_item['value'].val( JSON.stringify( $current_item['settings_array'] )  ).change();

			$MODAL_EDIT.find('iframe').attr('src', '' );

			$MODAL_EDIT.removeClass('show');

			$('body').trigger('composer-edit', $current_item['this'].parent().closest('.composer-item') );

		}

		$COMPOSER.on( 'dblclick', '.composer-item-handlebar', composer_item_edit ) ;
		$COMPOSER.on( 'click', '.composer-item-edit', composer_item_edit ) ;

		// $COMPOSER.on( 'change', '.composer-item-value', function(e) {
		//
		// 	parent = $('body').trigger('composer-edit', $(this).closest('.composer-item').parent().closest('.composer-item') );
		//
    //   if( $(parent).length !== 0 ) {
		//
    //    $(parent).trigger('element-update', parent );
		//
    //   }
		//
	  // 	update_composer();
		//
		// });

		/*
		 *
		 * clone_item
		 *
		*/
		function clone_item(e) {

			$model = $(this).closest('.composer-item');

			$clone = $model.clone();

			$clone.insertAfter($model).hide().fadeIn(500);

			$('body').trigger('composer-clone', $model.parent().closest('.composer-item') );

		}

		$COMPOSER.on( 'click', '.composer-item-clone', clone_item ) ;


		/*
		 *
		 * delete_item
		 *
		*/
		function delete_item(){

			$element = $(this).closest('.composer-item');

			$parent_before_delete = $element.parent().closest('.composer-item');

			$(this).closest('.composer-item').remove();

			$('body').trigger('composer-clone', $parent_before_delete );

		}

		$COMPOSER.on('click', '.composer-item-delete', delete_item );


		/*
		 *
		 * close_modal_add
		 *
		*/
		function close_modal_add(){

			$MODAL_EDIT.find('iframe').hide().attr('src', '' );

			$MODAL_EDIT.removeClass('show');

			$MODAL_ADD.removeClass('show');

		}

		$COMPOSER.on( 'click', '.composer-item-add-content', open_modal_add ) ;
		$COMPOSER.on( 'click', '.composer-modal-close', close_modal_add ) ;


		/*
		 *
		 * UPDATE
		 *
		*/
		$('body').on('composer-add', function( event, parent ) {

      if( $(parent).length !== 0 ) {

        $(parent).trigger('element-update', parent );

      }

	  	update_composer();

		});

		$('body').on('composer-edit', function( event, parent ) {

      if( $(parent).length !== 0 ) {

        $(parent).trigger('element-update', parent );

      }

	  	update_composer();

		});

		$('body').on('composer-sort', function( event, parent  ) {

      if( $(parent).length !== 0 ) {

        $(parent).trigger('element-update', parent );

      }

	  	update_composer();

		});

		$('body').on('composer-clone', function( event, parent  ) {

      if( $(parent).length !== 0 ) {

        $(parent).trigger('element-update', parent );

      }

	  	update_composer();

		});

		$('body').on('composer-delete', function( event, parent  ) {

      if( $(parent).length !== 0 ) {

        $(parent).trigger('element-update', parent );

      }

	  	update_composer();

		});

		$('body').on('composer-update', function( event ) {

	  	update_composer();

		});

		// $('body').on('composer-sort composer-edit composer-clone composer-delete', function( event ) {
		//
		// 	console.log('composer-event:composer-all');
		//
	  // 	update_composer();
		//
		// });


		function update_composer(e) {

			console.log('update_composer');

			var output = {};

			var composer = [];

			$COMPOSER_ROWS.find('> .composer-item').each( function( index_element, element ) {

				element_settings = $.parseJSON( $(element).find('>.composer-item-value').val() );

				composer.push(element_settings);

			});

			output = composer;

			$data = JSON.stringify( output );
			
			console.log( $data );

			if ( $data == '[]' ) $data = "";

			$VALUE.val( $data );

			init_empty_message();

			//sortable_rows();
			sortable_items();

			init_column_size();

			$HISTORY.push( $data );




			// console.log('update_composer', $HISTORY );

			//$('body').trigger( 'composer-update', $COMPOSER_ROWS );

		};

		//$FIELD.on('change', '.composer-item-value', update_composer );

		//$('body').on('element-update', function(){

			// setTimeout(update_composer, 1000);
			//update_composer();

		//});

		function update_element_settings( element, element_settings ){

			$(element).find('> .composer-item-value').val( JSON.stringify( element_settings ) );

		}

		/*
		 *
		 * GLOBAL ACTIONS
		 *
		*/

		function view_fullscreen(){

			$COMPOSER.toggleClass('composer-fullscreen');

		}

		function view_xray(){

			$COMPOSER.toggleClass('composer-xray');

		}

		function view_source(){

			$COMPOSER.toggleClass('composer-source-show');

		}

		function view_debug(){

			$COMPOSER.find('.composer-row-value, .composer-column-value, .composer-item-value').toggle();


		}

		function view_preview(){

			$COMPOSER.toggleClass('composer-preview-show');

		}
		$(document).keypress( function(e) {

		  	if ( e.altKey && e.keyCode === 960) {
		    	$COMPOSER.toggleClass('composer-preview-show');
		    	e.preventDefault();
			}

		});

		$COMPOSER.on( 'click', '.composer-action-fullscreen', view_fullscreen ) ;
		$COMPOSER.on( 'click', '.composer-action-xray', view_xray ) ;
		$COMPOSER.on( 'click', '.composer-action-source', view_source ) ;
		$COMPOSER.on( 'click', '.composer-action-debug', view_debug ) ;
		$COMPOSER.on( 'click', '.composer-action-preview', view_preview ) ;

		/*
		 *
		 * HOVER
		 *
		*/
		$COMPOSER.on( 'mouseover mouseout', '.composer-item', function(e){

			$COMPOSER.find('.composer-item').removeClass('hover-parent');

			if ( e.type ==  'mouseout') {
				$(this).removeClass('hover');
			} else {
				$(this).addClass('hover');
				$(this).parent().closest('.composer-item').addClass('hover-parent');
			}
			
			e.stopPropagation();

		});

		/*
		 *
		 * HELPERS
		 *
		*/
		function init_empty_message() {

				if( $COMPOSER.find('.composer-layout > .composer-items').children().length == 0 ) {

					$COMPOSER.find('.composer-empty').css('display','block');

				} else {

					$COMPOSER.find('.composer-empty').css('display','none');

				}

		}

		function init_column_size(){

			$COMPOSER.find('.composer-item').each(function(index, el) {

				if ( $(this).outerWidth() < 180 ) {
					$(this).addClass('column-expend');
				} else {
					$(this).removeClass('column-expend');
				}

			});

		}

		$( window ).resize( init_column_size );

		init_column_size();

		init_empty_message();
		
		$COMPOSER.css('visibility', 'visible' );

	});

	removeFromArray = function(value, arr) {
	    return $.grep(arr, function(elem, index) {
	        return elem !== value;
	    });
	};

}

$(document).ready(function(){

	$('body').find('.wp-field-composer').wp_field_composer();

});

}(jQuery));
